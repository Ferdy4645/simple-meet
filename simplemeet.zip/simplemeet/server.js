// server.js
// Backend SimpleMeet: Express (menyajikan file statis + routing room)
// + Socket.IO (signaling WebRTC & chat real-time)
// Tidak ada database. Semua state disimpan di memori (Map) selama server hidup.

const express = require('express');
const http = require('http');
const path = require('path');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const PORT = process.env.PORT || 3000;

// Kapasitas maksimum peserta per room (fokus 1-on-1 dulu)
const MAX_PARTICIPANTS_PER_ROOM = 2;

// Menyajikan file statis (html, css, js) dari folder public
app.use(express.static(path.join(__dirname, 'public')));

// Halaman utama (buat / gabung room)
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Halaman meeting room, contoh URL: /room/ABC123
app.get('/room/:roomId', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'room.html'));
});

// ================== SOCKET.IO SIGNALING ==================
io.on('connection', (socket) => {
  // ---- Bergabung ke room ----
  socket.on('join-room', ({ roomId, userName }) => {
    if (!roomId || !userName) return;

    const roomClients = io.sockets.adapter.rooms.get(roomId);
    const currentCount = roomClients ? roomClients.size : 0;

    // Batasi hanya 2 orang per room untuk versi 1-on-1
    if (currentCount >= MAX_PARTICIPANTS_PER_ROOM) {
      socket.emit('room-full');
      return;
    }

    // Simpan info di socket (tidak disimpan di database, hanya di memori sesi socket)
    socket.data.roomId = roomId;
    socket.data.userName = userName.substring(0, 30); // batasi panjang nama

    socket.join(roomId);

    // Beritahu socket ini bahwa join berhasil
    socket.emit('joined-room', { roomId });

    // Jika sudah ada 1 peserta lain di room, beritahu peserta itu
    // bahwa ada user baru bergabung, supaya dia membuat WebRTC offer.
    if (currentCount === 1) {
      socket.to(roomId).emit('user-joined', {
        socketId: socket.id,
        userName: socket.data.userName,
      });
    }
  });

  // ---- Relay WebRTC signaling (offer/answer/ice-candidate) ----
  socket.on('offer', ({ to, offer }) => {
    io.to(to).emit('offer', {
      from: socket.id,
      offer,
      userName: socket.data.userName,
    });
  });

  socket.on('answer', ({ to, answer }) => {
    io.to(to).emit('answer', {
      from: socket.id,
      answer,
      userName: socket.data.userName,
    });
  });

  socket.on('ice-candidate', ({ to, candidate }) => {
    io.to(to).emit('ice-candidate', {
      from: socket.id,
      candidate,
    });
  });

  // ---- Chat real-time ----
  socket.on('chat-message', ({ message }) => {
    const roomId = socket.data.roomId;
    if (!roomId || !message) return;

    const cleanMessage = String(message).substring(0, 1000); // batasi panjang pesan

    io.to(roomId).emit('chat-message', {
      socketId: socket.id,
      userName: socket.data.userName,
      message: cleanMessage,
      time: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
    });
  });

  // ---- Beritahu peserta lain saat status screen share berubah (opsional info UI) ----
  socket.on('screen-share-status', ({ sharing }) => {
    const roomId = socket.data.roomId;
    if (!roomId) return;
    socket.to(roomId).emit('screen-share-status', {
      socketId: socket.id,
      userName: socket.data.userName,
      sharing,
    });
  });

  // ---- Saat user keluar / disconnect ----
  socket.on('leave-room', () => {
    handleLeave(socket);
  });

  socket.on('disconnect', () => {
    handleLeave(socket);
  });

  function handleLeave(socket) {
    const roomId = socket.data.roomId;
    if (!roomId) return;

    socket.to(roomId).emit('user-left', {
      socketId: socket.id,
      userName: socket.data.userName,
    });

    socket.leave(roomId);
    socket.data.roomId = null;
  }
});

server.listen(PORT, () => {
  console.log(`SimpleMeet berjalan di http://localhost:${PORT}`);
});
